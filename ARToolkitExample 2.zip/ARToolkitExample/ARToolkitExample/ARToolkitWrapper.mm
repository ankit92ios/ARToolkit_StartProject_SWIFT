//
//  ARToolkitWrapper.m
//  ARToolkitExample
//
//  Created by Ankit on 2/1/18.
//  Copyright © 2018 Demo. All rights reserved.
//

#import "ARToolkitWrapper.h"
using namespace std;
@implementation ARToolkitWrapper
- (void)isThisWorking
{
    printf("df");
   
}
@end
