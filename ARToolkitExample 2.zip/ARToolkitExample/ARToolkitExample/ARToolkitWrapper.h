//
//  ARToolkitWrapper.h
//  ARToolkitExample
//
//  Created by Ankit on 2/1/18.
//  Copyright © 2018 Demo. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "ar.h"
#include <AR/video.h>
#include <AR/gsub_es2.h>
#import <AR/sys/CameraVideo.h>

@interface ARToolkitWrapper : NSObject
- (void)isThisWorking;
@end
